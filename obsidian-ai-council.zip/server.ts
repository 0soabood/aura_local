import express from "express";
import { createServer as createViteServer } from "vite";
import process from "process";
import path from "path";
import { fileURLToPath } from "url";
import OpenAI from "openai";
import { CohereClient } from "cohere-ai";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: "50mb" }));

  // API Route for multi-agent chat
  app.post("/api/chat", async (req, res) => {
    const { query, context } = req.body;
    
    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");

    const sendEvent = (event: string, data: any) => {
      res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
    };

    try {
      sendEvent("status", { message: "Initializing AI Council..." });

      // Identify available agents
      const availableAgents = [];
      if (process.env.GROQ_API_KEY) availableAgents.push("groq");
      if (process.env.DEEPSEEK_API_KEY) availableAgents.push("deepseek");
      if (process.env.MISTRAL_API_KEY) availableAgents.push("mistral");
      if (process.env.OPENROUTER_API_KEY) availableAgents.push("openrouter");
      if (process.env.COHERE_API_KEY) availableAgents.push("cohere");

      if (availableAgents.length === 0) {
        sendEvent("error", { message: "No API keys configured. Please add them in the platform secrets." });
        res.end();
        return;
      }

      sendEvent("status", { message: `Agents online: ${availableAgents.join(", ")}` });

      let currentContext = context || "No context provided.";
      let intermediateFindings = "";

      // Agent 1: The Researcher (fast reading/extraction)
      // Preference: Groq (llama-3-8b) or DeepSeek
      if (availableAgents.includes("groq") || availableAgents.includes("deepseek")) {
        const agentName = availableAgents.includes("groq") ? "Groq (Llama 3)" : "DeepSeek";
        sendEvent("agent_update", { agent: agentName, action: "Reading vault and extracting key facts..." });
        
        const client = availableAgents.includes("groq") 
          ? new OpenAI({ baseURL: "https://api.groq.com/openai/v1", apiKey: process.env.GROQ_API_KEY })
          : new OpenAI({ baseURL: "https://api.deepseek.com", apiKey: process.env.DEEPSEEK_API_KEY });
        
        const model = availableAgents.includes("groq") ? "llama3-8b-8192" : "deepseek-chat";

        const response = await client.chat.completions.create({
          model,
          messages: [
            { role: "system", content: "You are the Researcher. Analyze the provided Obsidian vault context and extract the raw facts, quotes, and data most relevant to the user's query. Output only the findings." },
            { role: "user", content: `Context: ${currentContext}\n\nQuery: ${query}` }
          ]
        });

        intermediateFindings = response.choices[0].message.content || "";
        sendEvent("agent_complete", { agent: agentName, result: intermediateFindings });
      } else {
        intermediateFindings = `Context provided: ${currentContext}`;
      }

      // Agent 2: The Analyst (structuring/synthesizing)
      // Preference: Mistral or OpenRouter
      let structuredAnalysis = intermediateFindings;
      if (availableAgents.includes("mistral") || availableAgents.includes("openrouter")) {
        const agentName = availableAgents.includes("mistral") ? "Mistral" : "OpenRouter Analyst";
        sendEvent("agent_update", { agent: agentName, action: "Structuring data and formulating answer..." });
        
        const client = availableAgents.includes("mistral")
          ? new OpenAI({ baseURL: "https://api.mistral.ai/v1", apiKey: process.env.MISTRAL_API_KEY })
          : new OpenAI({ baseURL: "https://openrouter.ai/api/v1", apiKey: process.env.OPENROUTER_API_KEY });

        const model = availableAgents.includes("mistral") ? "mistral-large-latest" : "meta-llama/llama-3.1-8b-instruct"; // OpenRouter fallback model

        const response = await client.chat.completions.create({
          model,
          messages: [
            { role: "system", content: "You are the Analyst. Take the researcher's raw findings and build a logical, structured response that directly answers the user's query." },
            { role: "user", content: `Query: ${query}\n\nFindings:\n${intermediateFindings}` }
          ]
        });

        structuredAnalysis = response.choices[0].message.content || "";
        sendEvent("agent_complete", { agent: agentName, result: structuredAnalysis });
      }

      // Agent 3: The Communicator (Cohere or fallback)
      let finalResponse = structuredAnalysis;
      if (availableAgents.includes("cohere")) {
        sendEvent("agent_update", { agent: "Cohere", action: "Refining the final response for clarity..." });
        
        const cohere = new CohereClient({
          token: process.env.COHERE_API_KEY!,
        });

        const response = await cohere.chat({
          message: `User Query: ${query}\n\nDraft Answer: ${structuredAnalysis}\n\nPlease review this draft and produce a polished, readable, and perfectly formatted final response.`,
          model: "command-r-plus",
        });

        finalResponse = response.text;
        sendEvent("agent_complete", { agent: "Cohere", result: finalResponse });
      } else if (availableAgents.includes("openrouter") || availableAgents.includes("deepseek")) {
         // Use an available one as the final communicator if Cohere is missing
         const fallback = availableAgents.includes("deepseek") ? "deepseek" : "openrouter";
         sendEvent("agent_update", { agent: fallback, action: "Refining the final response for clarity..." });

         const client = fallback === "deepseek"
          ? new OpenAI({ baseURL: "https://api.deepseek.com", apiKey: process.env.DEEPSEEK_API_KEY })
          : new OpenAI({ baseURL: "https://openrouter.ai/api/v1", apiKey: process.env.OPENROUTER_API_KEY });
         const model = fallback === "deepseek" ? "deepseek-chat" : "meta-llama/llama-3.1-8b-instruct";

         const response = await client.chat.completions.create({
          model,
          messages: [
            { role: "system", content: "You are the Communicator. Take the draft answer and ensure it is polished, clear, and perfectly formatted in Markdown to directly address the user." },
            { role: "user", content: `Query: ${query}\n\nDraft:\n${structuredAnalysis}` }
          ]
         });

         finalResponse = response.choices[0].message.content || "";
         sendEvent("agent_complete", { agent: fallback, result: finalResponse });
      }

      sendEvent("done", { finalResponse });
      res.end();
    } catch (error: any) {
      console.error("AI Council Error:", error);
      sendEvent("error", { message: error.message || "An error occurred during multi-agent processing." });
      res.end();
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
