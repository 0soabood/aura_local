import { useState, useRef, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { FolderOpen, FileText, Send, Terminal, Network, Loader2, Cpu, BrainCircuit } from "lucide-react";

interface VaultFile {
  name: string;
  path: string;
  content: string;
}

interface ChatMessage {
  id: string;
  role: "user" | "council";
  query?: string;
  finalResponse?: string;
  agentLogs: { agent: string; action?: string; result?: string; status: "working" | "done" | "error" }[];
}

export default function App() {
  const [vaultFiles, setVaultFiles] = useState<VaultFile[]>([]);
  const [isReadingVault, setIsReadingVault] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputMessage, setInputMessage] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Auto-scroll on new messages
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: "smooth", block: "end" });
    }
  }, [messages]);

  useEffect(() => {
    // Add dark mode toggle class by default to body
    document.documentElement.classList.add("dark");
  }, []);

  const handleOpenVault = () => {
    const input = document.createElement("input");
    input.type = "file";
    // @ts-ignore
    input.webkitdirectory = true;
    // @ts-ignore
    input.directory = true;
    input.multiple = true;

    input.onchange = async (e) => {
      setIsReadingVault(true);
      const fileList = (e.target as HTMLInputElement).files;
      if (!fileList) {
        setIsReadingVault(false);
        return;
      }

      const files: VaultFile[] = [];
      for (let i = 0; i < fileList.length; i++) {
        const file = fileList[i];
        if (file.name.endsWith(".md") && !file.webkitRelativePath.includes("/.")) {
          try {
            const content = await file.text();
            files.push({ name: file.name, path: file.webkitRelativePath || file.name, content });
          } catch (err) {
            console.error("Failed to read file", file.name, err);
          }
        }
      }

      // Limit to max 100 files or 5MB of text to prevent payload crashes
      const truncatedFiles = files.slice(0, 100);
      setVaultFiles(truncatedFiles);
      setIsReadingVault(false);
    };

    input.click();
  };

  const handleSendMessage = async () => {
    if (!inputMessage.trim() || isProcessing) return;

    const query = inputMessage;
    setInputMessage("");
    setIsProcessing(true);

    const messageId = Date.now().toString();
    const newMsg: ChatMessage = { id: messageId, role: "council", query, agentLogs: [] };
    
    setMessages((prev) => [...prev, { id: messageId + "_user", role: "user", query }, newMsg]);

    const vaultContext = vaultFiles.map(f => `--- ${f.path} ---\n${f.content.substring(0, 2000)}`).join("\n\n");

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query, context: vaultContext }),
      });

      if (!response.body) throw new Error("No response body");

      const reader = response.body.getReader();
      const decoder = new TextDecoder("utf-8");

      let done = false;
      while (!done) {
        const { value, done: readerDone } = await reader.read();
        done = readerDone;
        if (value) {
          const chunk = decoder.decode(value);
          const lines = chunk.split("\n\n");

          for (const line of lines) {
            if (!line.startsWith("event: ")) continue;
            
            const eventLine = line.split("\n")[0].replace("event: ", "");
            const dataLine = line.split("\n")[1]?.replace("data: ", "") || "{}";
            
            let data;
            try { data = JSON.parse(dataLine); } catch (e) { continue; }

            setMessages((prev) => {
              const messagesList = [...prev];
              const currentMsgIndex = messagesList.findIndex(m => m.id === messageId);
              if (currentMsgIndex === -1) return prev;
              
              const currentMsg = { ...messagesList[currentMsgIndex] };
              const agentLogs = [...currentMsg.agentLogs];

              if (eventLine === "status" || eventLine === "agent_update") {
                const agentId = data.agent || "System";
                const existingLogIndex = agentLogs.findIndex(l => l.agent === agentId);
                
                if (existingLogIndex >= 0) {
                  agentLogs[existingLogIndex].action = data.action || data.message;
                  agentLogs[existingLogIndex].status = "working";
                } else {
                  agentLogs.push({ agent: agentId, action: data.action || data.message, status: "working" });
                }
              }

              if (eventLine === "agent_complete") {
                const existingLogIndex = agentLogs.findIndex(l => l.agent === data.agent);
                if (existingLogIndex >= 0) {
                  agentLogs[existingLogIndex].result = data.result;
                  agentLogs[existingLogIndex].status = "done";
                }
              }

              if (eventLine === "done") {
                currentMsg.finalResponse = data.finalResponse;
              }

              if (eventLine === "error") {
                currentMsg.finalResponse = `Error: ${data.message}`;
              }

              currentMsg.agentLogs = agentLogs;
              messagesList[currentMsgIndex] = currentMsg;
              return messagesList;
            });
          }
        }
      }
    } catch (error) {
      console.error(error);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="flex h-screen w-full bg-background text-foreground overflow-hidden font-sans relative mesh-bg">
      
      {/* Left Sidebar - Vault Explorer */}
      <div className="w-80 flex-shrink-0 border-r border-white/10 glass-panel flex flex-col h-full shadow-2xl z-10">
        <div className="p-6 pb-4 border-b border-white/10 bg-black/20">
          <div className="flex items-center gap-2 mb-2">
            <Network className="w-6 h-6 text-primary" />
            <h1 className="text-xl font-bold tracking-tight">AI Council</h1>
          </div>
          <p className="text-sm text-muted-foreground mb-4">Multi-Agent Obsidian Analyzer</p>
          
          <Button 
            onClick={handleOpenVault} 
            className="w-full gap-2 font-medium"
            disabled={isReadingVault || isProcessing}
          >
            {isReadingVault ? <Loader2 className="w-4 h-4 animate-spin" /> : <FolderOpen className="w-4 h-4" />}
            {isReadingVault ? "Indexing Vault..." : "Connect Vault"}
          </Button>
        </div>

        <ScrollArea className="flex-1 p-4">
          {vaultFiles.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-40 text-center space-y-3 px-4">
              <FolderOpen className="w-8 h-8 text-muted-foreground opacity-50" />
              <p className="text-sm text-muted-foreground">Select an Obsidian vault folder to begin analysis.</p>
            </div>
          ) : (
            <div className="space-y-2">
              <div className="text-xs font-semibold uppercase text-muted-foreground px-2 mb-2 tracking-wider flex justify-between">
                <span>Indexed Files</span>
                <span>{vaultFiles.length}</span>
              </div>
              {vaultFiles.map((file, i) => (
                <div key={i} className="flex items-center gap-2 px-3 py-2 rounded-md hover:bg-white/5 text-sm group cursor-default transition-colors">
                  <FileText className="w-4 h-4 text-indigo-400/60 group-hover:text-indigo-400 transition-colors" />
                  <span className="truncate flex-1 text-slate-300 group-hover:text-slate-100">{file.name}</span>
                </div>
              ))}
            </div>
          )}
        </ScrollArea>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col h-full relative">
        {/* Background elements handled by mesh-bg on parent */}

        <ScrollArea className="flex-1 px-8 py-8">
          <div className="max-w-4xl mx-auto space-y-8 pb-4">
            
            {messages.length === 0 && (
              <div className="flex flex-col items-center justify-center h-[60vh] space-y-6 text-center animate-in fade-in slide-in-from-bottom-4 duration-1000">
                <div className="p-4 rounded-full bg-primary/10 text-primary">
                  <BrainCircuit className="w-12 h-12" />
                </div>
                <div>
                  <h2 className="text-2xl font-semibold tracking-tight mb-2">The Council is Ready</h2>
                  <p className="text-muted-foreground max-w-md mx-auto">
                    Connect your vault and ask questions. Groq, DeepSeek, Mistral, and Cohere will collaborate to provide synthesized answers.
                  </p>
                </div>
              </div>
            )}

            {messages.map((msg, i) => (
              <div key={i} className="space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-500">
                
                {msg.role === "user" && (
                  <div className="flex justify-end">
                    <div className="bg-primary text-primary-foreground px-6 py-3 rounded-2xl rounded-tr-sm max-w-[80%] shadow-md">
                      <p className="font-medium">{msg.query}</p>
                    </div>
                  </div>
                )}

                {msg.role === "council" && (
                  <div className="space-y-4">
                    {/* Agent Thinking Logs */}
                    <div className="grid gap-3 max-w-[85%]">
                      {msg.agentLogs.map((log, idx) => {
                        let bubbleClass = "agent-bubble-default";
                        const agentName = log.agent.toLowerCase();
                        if (agentName.includes("groq") || agentName.includes("llama") || agentName.includes("system")) bubbleClass = "agent-bubble-orchestrator";
                        if (agentName.includes("deepseek") || agentName.includes("research")) bubbleClass = "agent-bubble-researcher";
                        if (agentName.includes("mistral") || agentName.includes("analyst")) bubbleClass = "agent-bubble-analyst";
                        if (agentName.includes("cohere")) bubbleClass = "agent-bubble-cohere";
                        if (agentName.includes("openrouter")) bubbleClass = "agent-bubble-openrouter";

                        return (
                          <div key={idx} className={`glass-panel rounded-xl p-4 flex gap-4 ${bubbleClass} shadow-md`}>
                            <div className="mt-1">
                              {log.status === "working" ? (
                                <Loader2 className="w-5 h-5 animate-spin text-primary/80" />
                              ) : (
                                <Cpu className="w-5 h-5 text-emerald-400" />
                              )}
                            </div>
                            <div className="flex-1 space-y-1">
                              <p className="text-[11px] font-bold text-foreground/80 uppercase tracking-widest flex items-center gap-2">
                                {log.agent}
                                <span className="text-[9px] font-normal text-muted-foreground tracking-normal">
                                  {log.status === "working" ? "active" : "finished"}
                                </span>
                              </p>
                              {log.action && <p className="text-sm text-foreground/90 leading-relaxed font-medium">{log.action}</p>}
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    {/* Final Synthesized Response */}
                    {msg.finalResponse && (
                      <div className="glass-panel border-white/10 shadow-xl px-8 py-6 rounded-2xl rounded-tl-sm max-w-[90%] prose prose-invert max-w-none">
                        {/* We use a simple whitespace pre-wrap for now, but markdown rendering could be added */}
                        <div className="whitespace-pre-wrap font-sans text-foreground/90 leading-relaxed text-[15px]">
                          {msg.finalResponse}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            ))}
            <div ref={scrollRef} className="h-1" />
          </div>
        </ScrollArea>

        {/* Input Area */}
        <div className="p-6 border-t border-white/10 glass-panel bg-transparent rounded-none z-10">
          <div className="max-w-4xl mx-auto flex gap-3 items-end relative">
            <div className="flex-1 glass-panel bg-white/5 border-white/10 rounded-2xl focus-within:ring-2 ring-indigo-500/50 transition-all shadow-inner">
              <textarea
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    handleSendMessage();
                  }
                }}
                placeholder={vaultFiles.length === 0 ? "Connect your vault first..." : "Ask the Council about your vault..."}
                disabled={vaultFiles.length === 0 || isProcessing}
                className="w-full bg-transparent p-4 min-h-[60px] max-h-40 outline-none resize-none disabled:opacity-50 text-[15px] placeholder:text-muted-foreground/50"
                rows={1}
              />
            </div>
            <Button 
              size="icon" 
              className="h-[60px] w-[60px] rounded-2xl flex-shrink-0 shadow-lg bg-indigo-500 hover:bg-indigo-600 text-white border-0 transition-colors"
              disabled={vaultFiles.length === 0 || !inputMessage.trim() || isProcessing}
              onClick={handleSendMessage}
            >
              {isProcessing ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5 ml-1" />}
            </Button>
          </div>
          <p className="text-center text-xs text-muted-foreground mt-4 font-mono">
            Council Members: Groq, Mistral, DeepSeek, Cohere, OpenRouter
          </p>
        </div>
      </div>
      
    </div>
  );
}
